import pygame
from pygame.locals import *
from sys import exit
x = 40
y = 30
x_speed = 2
y_speed = 1

screen = pygame.display.set_mode((800, 800))
pygame.display.set_caption("拯救黑洞")
screen.fill((255,255,255))
pygame.display.update()

pygame.draw.circle(screen, (0, 0, 0), (400,300), 100)
pygame.draw.circle(screen, (255, 0, 0), (x,y), 30)
pygame.display.update()

while True:
    events = pygame.event.get()
    for event in events:
        if event.type == QUIT:
            exit()
        if event.type == MOUSEBUTTONDOWN:

            pygame.display.update()
    x += x_speed
    y += y_speed
    if x<30 or x>770:
        x_speed = -x_speed
    if y<30 or y>770:
        y_speed = -y_speed
    screen.fill((255, 255, 255))
    pygame.draw.circle(screen, (0, 0, 0), (400, 300), 100)
    pygame.draw.circle(screen, (255, 0, 0), (x, y), 30)
    pygame.display.update()